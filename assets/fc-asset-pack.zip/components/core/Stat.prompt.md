An editorial metric, a large display number with a quiet label. Sits well in a section of the editorial flow.

```jsx
<Stat value="48" label="projects shipped" note="since 2021" />
```

Keep the surrounding cell sparse; the number should have room.
