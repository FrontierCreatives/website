The primary action element, softly rounded, warm, unhurried.

```jsx
<Button variant="primary" arrow>Start a project</Button>
<Button variant="secondary">See work</Button>
<Button variant="ghost" size="sm">Learn more</Button>
```

Accent belongs to `primary` only; keep one primary action per view. `secondary` is a quiet warm fill; `ghost` is text with an accent tint on hover.
