import React from 'react';

/* The four palette tints, for gentle category tags. Coral is the default;
   the others are used sparingly. Not a structural color-coding system. */
const COLORS = {
  coral: ['var(--coral-tint)', 'var(--coral-ink)'],
  sand:  ['var(--sand-tint)',  'var(--on-sand)'],
  sage:  ['var(--sage-tint)',  'var(--on-sage)'],
  teal:  ['var(--teal-tint)',  'var(--teal-ink)'],
  plain: ['var(--surface-alt)', 'var(--text-secondary)'],
};

/**
 * Tag, a small category chip. Borderless, quiet. Selected/active fills the
 * accent tint; a color may be set for a gentle category hue.
 */
export function Tag({ children, color = 'plain', selected = false, style, ...rest }) {
  const key = selected && color === 'plain' ? 'coral' : color;
  const [bg, fg] = COLORS[key] || COLORS.plain;
  return (
    <button
      aria-pressed={selected}
      style={{
        display: 'inline-flex', alignItems: 'center', border: 'none',
        padding: '6px 14px', borderRadius: 'var(--radius-full)',
        fontFamily: 'var(--font-body)', fontWeight: 600, fontSize: 'var(--text-sm)',
        cursor: 'pointer', background: bg, color: fg,
        transition: 'background var(--dur-fast) var(--ease), color var(--dur-fast) var(--ease)',
        ...style,
      }}
      {...rest}
    >
      {children}
    </button>
  );
}
