A borderless editorial row for past events, links, or entries, separated from its siblings by air rather than rules.

```jsx
<ListItem lead="Mar 2026" title="On designing with agents" meta="A talk by Ada Okonkwo" trailing="→" onClick={...} />
<ListItem lead="Feb 2026" title="Prototyping night" meta="Open floor, six demos" trailing="→" />
```

Stack several with no dividers; the vertical padding is the separation. Keep meta to one quiet line.
