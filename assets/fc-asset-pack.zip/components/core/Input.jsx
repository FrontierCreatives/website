import React from 'react';

/** Input, warm, softly rounded field with optional label + helper. */
export function Input({ label, helper, id, invalid = false, style, ...rest }) {
  const [focus, setFocus] = React.useState(false);
  const fid = id || `in-${Math.random().toString(36).slice(2, 8)}`;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      {label && (
        <label htmlFor={fid} style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 'var(--text-sm)', color: 'var(--text-primary)' }}>{label}</label>
      )}
      <input
        id={fid}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        style={{
          fontFamily: 'var(--font-body)', fontSize: 'var(--text-lg)', color: 'var(--text-primary)',
          background: 'var(--surface-card)', padding: '12px 16px', borderRadius: 'var(--radius-md)',
          border: 'none',
          boxShadow: invalid
            ? 'inset 0 0 0 1.5px var(--danger)'
            : focus ? 'inset 0 0 0 1.5px var(--accent)' : 'inset 0 0 0 1px var(--border)',
          outline: focus ? '3px solid color-mix(in srgb, var(--accent) 20%, transparent)' : 'none',
          transition: 'box-shadow var(--dur-fast) var(--ease)',
          width: '100%', boxSizing: 'border-box', ...style,
        }}
        {...rest}
      />
      {helper && (
        <span style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', color: invalid ? 'var(--danger)' : 'var(--text-tertiary)' }}>{helper}</span>
      )}
    </div>
  );
}
