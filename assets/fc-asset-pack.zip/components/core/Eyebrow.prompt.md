A small warm editorial kicker above a heading, the system's only label style.

```jsx
<Eyebrow>This month</Eyebrow>
<h2 className="t-h2">Selected work</h2>
```

Keep it short (1–3 words). `tone="muted"` when accent would be too loud.
