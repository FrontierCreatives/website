import React from 'react';

const TINTS = {
  coral: 'var(--coral-tint)', sand: 'var(--sand-tint)',
  sage: 'var(--sage-tint)', teal: 'var(--teal-tint)',
};
const INK = {
  coral: 'var(--coral-ink)', sand: 'var(--on-sand)',
  sage: 'var(--on-sage)', teal: 'var(--teal-ink)',
};

/**
 * Person, a borderless presenter/attendee item: a soft round avatar (initials
 * on a palette tint, or an image) with a name and role stacked beneath. Meant
 * for a restrained row that stays subordinate to the editorial flow.
 */
export function Person({ name = '', role, initials, tint = 'coral', size = 88, imageSrc, style, ...rest }) {
  const ini = initials || name.split(' ').map(w => w[0]).slice(0, 2).join('');
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 12, ...style }} {...rest}>
      <div
        style={{
          width: size, height: size, borderRadius: '50%',
          background: imageSrc ? `center/cover url(${imageSrc})` : (TINTS[tint] || TINTS.coral),
          color: INK[tint] || INK.coral,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: size * 0.34,
          boxShadow: 'var(--shadow-sm)',
        }}
      >{imageSrc ? '' : ini}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        <span style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 'var(--text-lg)', color: 'var(--text-primary)' }}>{name}</span>
        {role && <span style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', color: 'var(--text-secondary)' }}>{role}</span>}
      </div>
    </div>
  );
}
