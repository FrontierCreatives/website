import * as React from 'react';

/** A small warm editorial kicker above a heading (the system's label style). */
export interface EyebrowProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** accent (default) or muted. */
  tone?: 'accent' | 'muted';
  children?: React.ReactNode;
}

export function Eyebrow(props: EyebrowProps): JSX.Element;
