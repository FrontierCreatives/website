A borderless presenter/attendee item, a soft round avatar with a name and role.

```jsx
<Person name="Ada Okonkwo" role="Design lead, Loom" tint="teal" />
<Person name="Ravi Patel" role="Independent" tint="sage" />
```

Lay a few out in a restrained, air-separated row; vary the tint gently across the four palette colors.
