import React from 'react';

const VARIANTS = {
  primary: { background: 'var(--brand)', color: 'var(--brand-contrast)' },
  secondary: { background: 'var(--surface-alt)', color: 'var(--text-primary)' },
  ghost: { background: 'transparent', color: 'var(--text-accent)' },
};
const SIZES = {
  sm: { padding: '9px 18px', fontSize: 'var(--text-sm)' },
  md: { padding: '13px 24px', fontSize: 'var(--text-lg)' },
  lg: { padding: '16px 30px', fontSize: 'var(--text-xl)' },
};

/**
 * Button, softly rounded, warm, Inter-semibold. Accent used only on
 * the primary action; secondary is a quiet warm fill, ghost is text-only.
 */
export function Button({
  children, variant = 'primary', size = 'md', arrow = false, disabled = false, style, ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const v = VARIANTS[variant] || VARIANTS.primary;
  const s = SIZES[size] || SIZES.md;
  const lift = hover && !disabled;
  return (
    <button
      disabled={disabled}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 8,
        fontFamily: 'var(--font-display)', fontWeight: 600, border: 'none',
        borderRadius: 'var(--radius-full)', cursor: disabled ? 'not-allowed' : 'pointer',
        transition: 'transform var(--dur-fast) var(--ease), box-shadow var(--dur-fast) var(--ease), background var(--dur-fast) var(--ease)',
        transform: lift ? 'translateY(-1px)' : 'translateY(0)',
        boxShadow: lift && variant === 'primary' ? 'var(--shadow-md)' : 'none',
        opacity: disabled ? 0.45 : 1,
        ...v, ...s,
        ...(lift && variant === 'primary' && { background: 'var(--brand-hover)' }),
        ...(lift && variant === 'secondary' && { background: 'var(--ink-150)' }),
        ...(lift && variant === 'ghost' && { background: 'var(--accent-tint)' }),
        ...style,
      }}
      {...rest}
    >
      {children}
      {arrow && (
        <span aria-hidden="true" style={{ transition: 'transform var(--dur-fast) var(--ease)', transform: lift ? 'translateX(3px)' : 'none' }}>→</span>
      )}
    </button>
  );
}
