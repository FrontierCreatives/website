import React from 'react';

/**
 * ListItem, a borderless editorial row for past events, links, or entries.
 * Separated from its siblings by air (not rules). A leading date/index sits
 * quietly to the left; the title carries the row; an optional trailing note
 * or arrow closes it. Hover warms the title to the accent.
 */
export function ListItem({ lead, title, meta, trailing, onClick, style, ...rest }) {
  const [hover, setHover] = React.useState(false);
  const clickable = !!onClick;
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => clickable && setHover(true)}
      onMouseLeave={() => clickable && setHover(false)}
      style={{
        display: 'flex', alignItems: 'baseline', gap: 'var(--space-6)',
        padding: 'var(--space-5) 0', cursor: clickable ? 'pointer' : 'default',
        ...style,
      }}
      {...rest}
    >
      {lead != null && (
        <span style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)', minWidth: 72, flex: '0 0 auto' }}>{lead}</span>
      )}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 4 }}>
        <span style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 'var(--text-xl)', color: hover ? 'var(--text-accent)' : 'var(--text-primary)', transition: 'color var(--dur-fast) var(--ease)' }}>{title}</span>
        {meta && <span style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-md)', color: 'var(--text-secondary)', lineHeight: 1.6 }}>{meta}</span>}
      </div>
      {trailing != null && (
        <span style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-md)', color: 'var(--text-tertiary)', flex: '0 0 auto' }}>{trailing}</span>
      )}
    </div>
  );
}
