import * as React from 'react';

/**
 * A borderless presenter/attendee item: soft round avatar (initials on a
 * palette tint, or an image) with name and role beneath. Use in a restrained
 * row that stays subordinate to the editorial flow.
 * @startingPoint section="Core" subtitle="Borderless presenter item" viewport="220x180"
 */
export interface PersonProps extends React.HTMLAttributes<HTMLDivElement> {
  name?: string;
  role?: string;
  /** Override the auto-derived initials. */
  initials?: string;
  /** Avatar tint from the palette. Default 'coral'. */
  tint?: 'coral' | 'sand' | 'sage' | 'teal';
  /** Avatar diameter in px. Default 88. */
  size?: number;
  /** Optional avatar image URL (replaces initials). */
  imageSrc?: string;
}

export function Person(props: PersonProps): JSX.Element;
