A small, borderless category chip. Active fills the coral tint; a `color` gives a gentle category hue.

```jsx
<Tag selected>All</Tag>
<Tag color="teal">Talk</Tag>
<Tag color="sage">Workshop</Tag>
<Tag color="sand">Social</Tag>
```

Keep tag rows short and let air separate them; the four hues are for gentle categorization, not loud color-coding.
