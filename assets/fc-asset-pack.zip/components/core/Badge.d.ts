import * as React from 'react';

/** A small warm label for counts, states, and metadata. */
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** neutral / accent / outline. Default 'neutral'. */
  tone?: 'neutral' | 'accent' | 'outline';
  children?: React.ReactNode;
}

export function Badge(props: BadgeProps): JSX.Element;
