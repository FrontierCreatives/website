import * as React from 'react';

/**
 * A borderless editorial row for past events, links, or entries. Rows are
 * separated by air, not rules. Hover warms the title to the accent.
 */
export interface ListItemProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Quiet leading value: a date, index, or short tag. */
  lead?: React.ReactNode;
  /** The row's title (carries the row). */
  title?: React.ReactNode;
  /** Secondary line beneath the title. */
  meta?: React.ReactNode;
  /** Trailing note or arrow. */
  trailing?: React.ReactNode;
  onClick?: React.MouseEventHandler;
}

export function ListItem(props: ListItemProps): JSX.Element;
