import React from 'react';

/**
 * Stat, an editorial metric: a large Inter number with a quiet label.
 * Reads as a considered spread, not a dashboard KPI.
 */
export function Stat({ value, label, note, style, ...rest }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 4, ...style }} {...rest}>
      <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 'var(--text-4xl)', lineHeight: 1, letterSpacing: 'var(--tracking-tight)', color: 'var(--text-primary)' }}>{value}</span>
      {label && <span style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-md)', color: 'var(--text-secondary)' }}>{label}</span>}
      {note && <span style={{ fontFamily: 'var(--font-body)', fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)' }}>{note}</span>}
    </div>
  );
}
