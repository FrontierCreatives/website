A small warm label for counts, states, and metadata.

```jsx
<Badge tone="accent">New</Badge>
<Badge tone="neutral">2026</Badge>
<Badge tone="outline">Draft</Badge>
```

Accent tone sparingly, it competes with the primary action if overused.
