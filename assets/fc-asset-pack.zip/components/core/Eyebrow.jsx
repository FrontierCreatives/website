import React from 'react';

/**
 * Eyebrow, a small warm editorial kicker above a heading. Uppercase, lightly
 * tracked, accent or muted. The system's label style; no clinical mono chrome.
 */
export function Eyebrow({ children, tone = 'accent', style, ...rest }) {
  const color = tone === 'muted' ? 'var(--text-tertiary)' : 'var(--text-accent)';
  return (
    <span
      style={{
        fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 'var(--text-xs)',
        letterSpacing: 'var(--tracking-eyebrow)', textTransform: 'uppercase', color,
        ...style,
      }}
      {...rest}
    >
      {children}
    </span>
  );
}
