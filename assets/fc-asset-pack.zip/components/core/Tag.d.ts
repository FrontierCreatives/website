import * as React from 'react';

/**
 * A small category chip. Borderless and quiet; active fills the accent tint.
 * A color sets a gentle category hue from the four-color palette (used
 * sparingly, never as structural coding).
 */
export interface TagProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** plain (neutral) / coral / sand / sage / teal. Default 'plain'. */
  color?: 'plain' | 'coral' | 'sand' | 'sage' | 'teal';
  /** Selected/active. When color is 'plain', selection uses the coral tint. Default false. */
  selected?: boolean;
  children?: React.ReactNode;
}

export function Tag(props: TagProps): JSX.Element;
