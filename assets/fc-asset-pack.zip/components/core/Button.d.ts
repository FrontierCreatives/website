import * as React from 'react';

/**
 * The primary action element: softly rounded, warm, Inter-semibold.
 * @startingPoint section="Core" subtitle="Rounded warm buttons" viewport="420x120"
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** primary (accent) / secondary (quiet warm fill) / ghost (text-only). Default 'primary'. */
  variant?: 'primary' | 'secondary' | 'ghost';
  /** Default 'md'. */
  size?: 'sm' | 'md' | 'lg';
  /** Trailing → that slides on hover. Default false. */
  arrow?: boolean;
  children?: React.ReactNode;
}

export function Button(props: ButtonProps): JSX.Element;
