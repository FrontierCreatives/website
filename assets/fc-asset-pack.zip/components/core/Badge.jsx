import React from 'react';

const TONES = {
  neutral: { background: 'var(--surface-alt)', color: 'var(--text-secondary)' },
  accent:  { background: 'var(--accent-tint)', color: 'var(--accent-ink)' },
  outline: { background: 'transparent', color: 'var(--text-secondary)', boxShadow: 'inset 0 0 0 1px var(--border)' },
};

/** Badge, a small warm label for counts, states, and metadata. */
export function Badge({ children, tone = 'neutral', style, ...rest }) {
  const t = TONES[tone] || TONES.neutral;
  return (
    <span
      style={{
        display: 'inline-flex', alignItems: 'center',
        padding: '4px 11px', borderRadius: 'var(--radius-full)',
        fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 'var(--text-2xs)',
        lineHeight: 1.5, ...t, ...style,
      }}
      {...rest}
    >
      {children}
    </span>
  );
}
