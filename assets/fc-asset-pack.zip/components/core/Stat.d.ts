import * as React from 'react';

/** An editorial metric: a large display number with a quiet label. */
export interface StatProps extends React.HTMLAttributes<HTMLDivElement> {
  /** The number / value, e.g. "48" or "12yrs". */
  value?: React.ReactNode;
  /** Short label beneath the value. */
  label?: React.ReactNode;
  /** Optional smaller note. */
  note?: React.ReactNode;
}

export function Stat(props: StatProps): JSX.Element;
