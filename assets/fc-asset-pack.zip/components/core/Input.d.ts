import * as React from 'react';

/** A warm, softly rounded text field with optional label + helper text. */
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  helper?: string;
  /** Error styling (danger inset + danger helper). Default false. */
  invalid?: boolean;
}

export function Input(props: InputProps): JSX.Element;
