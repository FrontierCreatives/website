A warm, softly rounded text field. Elevation is an inset hairline, not a hard outline.

```jsx
<Input label="Email" placeholder="you@studio.com" helper="We reply within a day." />
<Input label="Name" invalid helper="Required" />
```

`invalid` is the only place a second color (danger) appears; it is functional, not decorative.
