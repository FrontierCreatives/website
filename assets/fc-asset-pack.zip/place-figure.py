#!/usr/bin/env python3
"""
Place a curve-stitch figure into a scroll keyframe, or decode one that exists.

The rule this enforces
----------------------
A keyframe is a master figure under a similarity transform. Nothing else.

    p' = centre + scale * R(theta) * (p - (400, 400))

applied to every line of the master SVG, in file order, leaving the file's
line order untouched.

That last clause is the whole point. The figures morph by interpolating line i
of one keyframe toward line i of the next, so line i has to play the same
structural role in every figure. The masters in assets/textures/ are authored
on the shared skeleton (18 rings x 4 arms, ring-major) and already satisfy
this. Regenerating a figure from its own construction does not: a cardioid
written as a monotonic sweep and a star written as four arms of eighteen rings
each look correct standing still, and produce spaghetti the moment you morph
between them, because line i lands somewhere unrelated. Place the masters.
Never rebuild them.

Two further rules, both learned the hard way:

  * Never translate an existing keyframe to a new centre. The placed figures
    are full-bleed, wider than the viewBox; sliding one sideways pushes most
    of it off frame and it reads as a fan rather than a figure. Re-place from
    the master at the centre you want.
  * Decode with a similarity fit, not scale-plus-translate. Keyframes carry
    rotation. A scale-and-translate fit on a rotated keyframe reports error in
    the hundreds of pixels and looks like the line order is broken; it isn't.

Usage
-----
  place-figure.py place cardioid --scale 2.1976 --rot 0 --centre 1040 380
  place-figure.py decode star --keyframe kf0.json
  place-figure.py place pursuit --scale 2.29 --rot -20 --centre 300 470 --svg out.svg

`place` prints the keyframe as JSON, ready to paste into a KF array.
`decode` prints the scale, rotation, centre and worst-case error of an
existing keyframe, so an established composition can be reproduced exactly.
"""

import argparse
import json
import math
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
TEXTURES = os.path.join(HERE, "..", "assets", "textures")
MASTER_CENTRE = (400.0, 400.0)          # the masters are 800x800
FIGURES = ("star", "cardioid", "pursuit")
LINE_RE = re.compile(
    r'x1="([-\d.]+)"\s+y1="([-\d.]+)"\s+x2="([-\d.]+)"\s+y2="([-\d.]+)"'
)


def load_master(name):
    """The 72 lines of a master figure, in file order. Order is load-bearing."""
    path = os.path.join(TEXTURES, "fc-figure-%s.svg" % name)
    with open(path) as fh:
        lines = [[float(v) for v in m] for m in LINE_RE.findall(fh.read())]
    if len(lines) != 72:
        raise SystemExit("%s: expected 72 lines, found %d" % (path, len(lines)))
    return lines


def place(figure, scale, rot_deg, centre, precision=1):
    """Master figure -> keyframe. The formula, and the only correct way to move a figure."""
    theta = math.radians(rot_deg)
    a = math.cos(theta) * scale
    b = math.sin(theta) * scale
    cx, cy = centre
    out = []
    for line in figure:
        placed = []
        for i in (0, 2):
            u = line[i] - MASTER_CENTRE[0]
            v = line[i + 1] - MASTER_CENTRE[1]
            placed += [round(cx + a * u - b * v, precision),
                       round(cy + b * u + a * v, precision)]
        out.append(placed)
    return out


def _endpoints(lines):
    pts = []
    for l in lines:
        pts.append((l[0], l[1]))
        pts.append((l[2], l[3]))
    return pts


def decode(master, keyframe):
    """Keyframe -> (scale, rotation, centre, max error). Similarity fit, closed form."""
    A, B = _endpoints(master), _endpoints(keyframe)
    if len(A) != len(B):
        raise SystemExit("line counts differ: %d vs %d" % (len(A) // 2, len(B) // 2))
    n = len(A)
    ax = sum(p[0] for p in A) / n
    ay = sum(p[1] for p in A) / n
    bx = sum(p[0] for p in B) / n
    by = sum(p[1] for p in B) / n
    dot = cross = norm = 0.0
    for (px, py), (qx, qy) in zip(A, B):
        u, v = px - ax, py - ay
        s, t = qx - bx, qy - by
        dot += u * s + v * t
        cross += u * t - v * s
        norm += u * u + v * v
    a, b = dot / norm, cross / norm
    err = 0.0
    for (px, py), (qx, qy) in zip(A, B):
        u, v = px - ax, py - ay
        err = max(err, math.hypot(bx + a * u - b * v - qx, by + b * u + a * v - qy))
    # report the transform origin, not the endpoint centroid: place() measures
    # from (400,400), and a master whose own centroid sits off (400,400) would
    # otherwise decode to a centre that does not round-trip.
    du = ax - MASTER_CENTRE[0]
    dv = ay - MASTER_CENTRE[1]
    centre = (bx - (a * du - b * dv), by - (b * du + a * dv))
    return math.hypot(a, b), math.degrees(math.atan2(b, a)), centre, err


def as_svg(keyframe, width, height, stroke="#E76F51", weight="0.8", opacity="0.38"):
    body = "\n".join(
        '<line x1="%s" y1="%s" x2="%s" y2="%s"/>' % tuple(l) for l in keyframe
    )
    return (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" '
        'width="%d" height="%d">\n'
        '<g stroke="%s" stroke-width="%s" fill="none" opacity="%s">\n%s\n</g>\n</svg>\n'
        % (width, height, width, height, stroke, weight, opacity, body)
    )


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("place", help="master figure -> keyframe JSON")
    p.add_argument("figure", choices=FIGURES)
    p.add_argument("--scale", type=float, required=True)
    p.add_argument("--rot", type=float, default=0.0, help="degrees, clockwise positive")
    p.add_argument("--centre", "--center", nargs=2, type=float, required=True,
                   metavar=("X", "Y"))
    p.add_argument("--svg", metavar="PATH", help="also write a standalone SVG preview")
    p.add_argument("--viewbox", nargs=2, type=int, default=[1440, 900],
                   metavar=("W", "H"))

    d = sub.add_parser("decode", help="existing keyframe -> scale, rotation, centre")
    d.add_argument("figure", choices=FIGURES)
    d.add_argument("--keyframe", required=True,
                   help="JSON file holding one keyframe: 72 arrays of [x1,y1,x2,y2]")

    args = ap.parse_args()
    master = load_master(args.figure)

    if args.cmd == "place":
        kf = place(master, args.scale, args.rot, tuple(args.centre))
        if args.svg:
            with open(args.svg, "w") as fh:
                fh.write(as_svg(kf, args.viewbox[0], args.viewbox[1]))
            print("wrote %s" % args.svg, file=sys.stderr)
        print(json.dumps(kf, separators=(",", ":")))
        return

    with open(args.keyframe) as fh:
        kf = json.load(fh)
    scale, rot, centre, err = decode(master, kf)
    print("figure   %s" % args.figure)
    print("scale    %.4f" % scale)
    print("rotation %+.2f deg" % rot)
    print("centre   (%.1f, %.1f)" % centre)
    print("max err  %.2f px" % err)
    if err > 1.0:
        print("\nError above a pixel means this keyframe is not that master under a\n"
              "similarity transform. Check you picked the right figure before\n"
              "concluding the line order is wrong.", file=sys.stderr)


if __name__ == "__main__":
    main()
